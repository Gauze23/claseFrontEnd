# Eskimo Records - Landing Page

Landing page desarrollada como parte de una evaluación de Programación Front End.

## Contenido

- Encabezado con logo y navegación
- Imagen/banner principal
- Sección de servicios
- Sección de artistas
- Catálogo de lanzamientos
- Archivo de preservación
- Formulario de contacto
- Pie de página

## Tecnologías

- HTML5
- CSS3

## Autor

[Tu Nombre]  
Junio 2025
